package ru.ugnenko.ugnenko_task1;

public class SumControlle {
}
