package ru.ugnenko.ugnenko_task3;

public class SumController {
}
